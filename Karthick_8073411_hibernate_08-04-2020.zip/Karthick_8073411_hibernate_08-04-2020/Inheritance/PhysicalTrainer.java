package com.virtusa.Entity;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(name = "id")
public class PhysicalTrainer extends Trainer {

	private String game;
	private String day;
	public PhysicalTrainer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PhysicalTrainer(String game, String day) {
		super();
		this.game = game;
		this.day = day;
	}
	public String getGame() {
		return game;
	}
	public void setGame(String game) {
		this.game = game;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	@Override
	public String toString() {
		return "PhysicalTrainer [game=" + game + ", day=" + day + "]";
	}
	
	
}
