package com.virtusa.Entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Trainer {
	
	@Id
	@Column(name = "id")
	private int id;
	private String trName;
	

	public Trainer(int id, String name) {           
		super();
		this.id = id;
		this.trName = name;
	}

	public Trainer() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return trName;
	}

	public void setName(String name) {
		this.trName = name;
	}

	@Override
	public String toString() {
		return "Trainer [id=" + id + ", name=" + trName + "]";
	}
	
	
}
