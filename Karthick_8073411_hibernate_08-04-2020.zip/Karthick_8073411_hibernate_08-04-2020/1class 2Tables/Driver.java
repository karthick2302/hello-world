package com.virtusa.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name = "Driver")
@SecondaryTable(name = "Driver_Route")
public class Driver {

	@Id
	private int id;
	private String name;
	private double salary;
	@Column(table = "Driver_Route")
	private int vehicleId;
	@Column(table = "Driver_Route")
	private String origin;
	@Column(table = "Driver_Route")
	private String destination;
	
	public Driver() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Driver(int id, String name, double salary, int vehicleId, String origin, String destination) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.vehicleId = vehicleId;
		this.origin = origin;
		this.destination = destination;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "Driver [id=" + id + ", name=" + name + ", salary=" + salary + ", vehicleId=" + vehicleId + ", origin="
				+ origin + ", destination=" + destination + "]";
	}
	
	
}
