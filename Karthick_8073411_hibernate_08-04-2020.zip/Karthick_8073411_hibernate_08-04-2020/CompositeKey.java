package com.virtusa.Entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class CompositeKey implements Serializable{

	@Id
	@Column(name = "id")
	private int id;
	private String name;
	@Id
	@GeneratedValue
	private String phno;
	private String addr;
	public CompositeKey(int id, String name, String phno, String addr) {
		super();
		this.id = id;
		this.name = name;
		this.phno = phno;
		this.addr = addr;
	}
	public CompositeKey() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	@Override
	public String toString() {
		return "CompositeKey [id=" + id + ", name=" + name + ", phno=" + phno + ", addr=" + addr + "]";
	}
}
